# AltSitePath

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alt_path_id** | **str** | The identification number for the alt site path record. | [optional] 
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**site_path_id** | **str** | The identification number for the site path record. | [optional] 
**alt_agency_path_id** | **str** | The identification number for the alt site path agency. | [optional] 
**effective_date** | **str** | The date the record takes effect. | [optional] 
**end_date** | **str** | The record&#39;s end date. | [optional] 
**create_date** | **str** | The date the record was created. | [optional] 
**refresh_date** | **str** | The date the record was refreshed. | [optional] 
**user_id** | **str** | The user ID of the person who entered the data or the method by which the data was entered into the system. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


