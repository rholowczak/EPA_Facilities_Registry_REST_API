# Association

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**sub_component_id1** | **str** | the sub-component ID to be associated with subComponentId2. | 
**sub_component_id2** | **str** | the sub-component ID to be associated with subComponentId1. | 
**sub_association_average_percent** | **float** | The average percent of subAssociationInternalId1/subAssociationProgramSystemId1 as it relates to subAssociationInternalId2/subAssociationProgramSystemId2. For example, the average percent of emissions vented through a release point.  | [optional] 
**control_order** | **str** | stores the order a control variable is in the chain of the specified relationship | [optional] 
**series_parallel_ind** | **str** | denotes if a component is in a parallel sequence (or order) with another component | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


