# ReleasePoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**release_point_id** | **str** | An identifier by which the release point is referred to by the environmental system. | 
**release_point_alternate_id** | **str** | An alternative identification number maintained by an information management system for an environmental program. | 
**release_point_type_name** | **str** | Name that identifies the type of release point. Permitted values include Goose Neck, Downward-facing Vent, Vertical, Vertical with Rain Cap, Horizontal, etc. | 
**release_point_exit_gas_velocity_measure** | **float** | The velocity of an exit gas stream. | [optional] 
**release_point_exit_gas_flow_rate_measure** | **float** | The value of stack gas flow rate. | [optional] 
**release_point_exit_temperature_measure** | **float** | The temperature of an exit gas stream (measured in degrees Fahrenheit). | [optional] 
**release_point_fugitive_height_measure** | **float** | The fugitive release height above terrain of fugitive emissions. | [optional] 
**release_point_fugitive_width_measure** | **float** | The width of the fugitive release in the East-West direction as if the angle is zero degrees. | [optional] 
**release_point_fugitive_length_measure** | **float** | The length of the fugitive release in the North-South direction as if the angle is zero degrees. | [optional] 
**release_point_fugitive_angle_measure** | **float** | The orientation angle for the area in degrees from North, measured positive in the clockwise direction. | [optional] 
**release_point_latitude** | **float** | The measure of the angular distance on a meridian north or south of the equator, as reported by the data source.   | 
**release_point_longitude** | **float** | The measure of the angular distance on a meridian east or west of the prime meridian, as reported by the data source | 
**release_point_fugitive_line_pt1_latitude** | **float** | The measure of angular distance on a meridian north or south of the equator for a two-dimensional fugitive release. | [optional] 
**release_point_fugitive_line_pt1_longitude** | **float** | The measure of angular distance on a meridian east or west of the prime meridian for a two-dimensional fugitive release. | [optional] 
**release_point_fugitive_line_pt2_latitude** | **float** | The measure of angular distance on a meridian north or south of the equator for a two-dimensional fugitive release. | [optional] 
**release_point_fugitive_line_pt2_longitude** | **float** | The measure of angular distance on a meridian east or west of the prime meridian for a two-dimensional fugitive release. | [optional] 
**release_point_stack_diameter_measure** | **float** | The internal diameter of the stack at the release height. | [optional] 
**release_point_stack_height_measure** | **float** | The height of the stack from the ground. | [optional] 
**release_point_stack_height_uom_code** | **str** | The stack height unit of measure. | [optional] 
**release_point_stack_diameter_uom_code** | **str** | The stack diameter unit of measure. | [optional] 
**release_point_exit_gas_velocity_uom_code** | **str** | The unit of measure for the velocity of an exit gas stream value. | [optional] 
**release_point_exit_gas_flow_rate_uom_code** | **str** | The unit of measure for the stack gas flow rate value. | [optional] 
**release_point_fugitive_height_uom_code** | **str** | The fugitive release height unit of measure. | [optional] 
**release_point_fugitive_width_uom_code** | **str** | The fugitive width unit of measure code. Default is &#39;feet&#39;. | [optional] 
**release_point_fugitive_length_uom_code** | **str** | The fugitive length unit of measure code. Default is &#39;feet&#39;. | [optional] 
**release_point_fugitive_angle_msr_uom_code** | **str** | The fugitive angle unit of measure code | [optional] 
**release_point_reference_code** | **str** | The code that determines the location of the release point. | [optional] 
**release_point_data_collection_date** | **str** | The calendar date when data were collected. | [optional] 
**release_point_fugitive_diameter** | **float** | The diameter of the fugitive release. | [optional] 
**release_point_fugitive_diameter_uom_code** | **str** | The fugitive diameter unit of measure code | [optional] 
**release_point_collection_mth_code** | **str** | The code that represents the method used to determine the latitude and longitude coordinates for a point on the earth. | [optional] 
**release_point_collection_mth_comment** | **str** | The description of the code that represents the method used to determine the latitude and longitude coordinates for a point on the earth. | [optional] 
**release_point_type_code** | **str** | The release point type code. | [optional] 
**release_point_operating_status** | **str** | The operating status of the object of interest. Acceptable values are PLANNED, UNDER CONSTRUCTION, OPERATING, TEMPORARILY CLOSED, PERMANENTLY CLOSED, SEASONAL. | [optional] 
**release_point_operating_status_year** | **str** | The operating status year. | [optional] 
**release_point_source_system_program_code** | **str** | The code that represents the information management system which has responsibility for the data in a linked or interrelated information management system. | [optional] 
**release_point_fence_line_distance_measure** | **float** |  | [optional] 
**release_point_fence_line_distance_uom_code** | **str** |  | [optional] 
**release_point_comment** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


