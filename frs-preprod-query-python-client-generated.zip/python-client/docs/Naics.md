# Naics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**naics_code** | **str** | The code that represents a subdivision of an industry that accommodates user needs in the United States (six-digits). | [optional] 
**primary_indicator** | **str** | Indicates whether this SIC is the primary for the registry item. Acceptable values are: PRIMARY, SECONDARY, UNKNOWN. | 
**source_of_data** | **str** | Indicates the originating system for this information. | 
**last_reported_date** | **str** | The most recent date the corresponding data was reported to the Source of Data in ISO 8601 format. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


