# Unit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**unit_id** | **str** | An identifier by which the unit is referred to by the primary EPA environmental information system that collects air emission information. | 
**unit_alternate_id** | **str** | An alternative identification number maintained by an information management system for an environmental program. | 
**unit_alternate_name** | **str** | An alternative, historic or program specific name for the sub-component. | [optional] 
**unit_description** | **str** | Text description of the emissions unit. | 
**unit_type_code** | **str** | Code that identifies the type of emissions unit activity. | 
**unit_type_description** | **str** | The description of the unit type code, which identifies the type of emissions unit activity. | 
**unit_design_capacity** | **float** | The measure of the size of the unit based on the maximum continuous throughput capacity of the unit. | [optional] 
**unit_design_capacity_uom_code** | **str** | Unit of measure code for the design capacity of the emissions unit. | [optional] 
**unit_of_measure_description** | **str** | Description of the unit of measure code. | [optional] 
**unit_operation_date** | **str** | The date on which unit activity became operational. | [optional] 
**unit_comment** | **str** | Any comments regarding the emissions unit activity. | [optional] 
**unit_operating_status** | **str** | The operating status of the object of interest. Acceptable values are PLANNED, UNDER CONSTRUCTION, OPERATING, TEMPORARILY CLOSED, PERMANENTLY CLOSED, SEASONAL. | [optional] 
**unit_operating_status_year** | **str** | The operating status year. | [optional] 
**unit_permit_status** | **str** |  The permitting status of the object of interest. | [optional] 
**unit_permit_start_year** | **str** | The start year of the permitting status of the object. | [optional] 
**unit_permit_end_year** | **str** | The end year of the permitting status of the object. | [optional] 
**unit_source_system_program_code** | **str** | The code that represents the information management system which has responsibility for the data in a linked or interrelated information management system. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


