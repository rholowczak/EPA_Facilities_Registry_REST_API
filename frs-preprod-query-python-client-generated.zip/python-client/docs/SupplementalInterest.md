# SupplementalInterest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | [optional] 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | [optional] 
**supplemental_program_system_acronym** | **str** | The abbreviated name that represents the name of a supplemental information management system. For the purposes of FRS, supplemental systems include state program systems, compliance and enforcement systems, and program systems that include general permits. | [optional] 
**supplemental_program_system_id** | **str** | The unique identification number assigned to a judicial or formal administrative enforcement action, a compliance monitoring activity, a general permit, or a state environmental program. | [optional] 
**supplemental_interest_type** | **str** | The supplemental environmental permit or regulatory program that applies to the facility site or the environmental interest at the facility site. For the purposes of FRS, supplemental program interests include state programs, compliance and enforcement programs, and general permits. Refer to https://www.epa.gov/sites/production/files/2015-09/documents/standard_interests.pdf for list of supplemental interest types FRS accepts currently - this list can be added to. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


