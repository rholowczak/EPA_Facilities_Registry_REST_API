# Tribe

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**epa_id** | **float** | The EPA internal identifier of the tribe. | [optional] 
**bia_code** | **str** | The code that represents the American Indian tribe, band, or Alaskan Native entity. Permissible values for the Tribal Code data element are based on the BIA official list of tribal codes, e.g., 007 (St. Regis Band of Mohawk Indians of New York) or F09 (Birch Creek Tribe). | [optional] 
**tribe_name** | **str** | The name of the American Indian tribe, band, or Alaskan Native entity. Permissible values for the Tribal Name data element are based on the BIA federally recognized tribal list, e.g., St. Regis Band of Mohawk Indians of New York. | [optional] 
**last_reported_date** | **str** | The most recent date the corresponding data was reported to the Source of Data in ISO 8601 format. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


