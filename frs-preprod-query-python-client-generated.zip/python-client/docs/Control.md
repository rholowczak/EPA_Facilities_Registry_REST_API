# Control

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**control_id** | **str** | An identifier by which the control measure is referred to by the  information system that collected the air emission information. | 
**control_alternate_id** | **str** | An alternative identification number maintained by an information management system for an environmental program. | 
**control_capture_efficiency_percent** | **float** | An estimate of that portion of an affected emission stream that is collected and routed to the control measures when the capture or collection system is operating as designed, reported as a percent. | [optional] 
**control_effectiveness_percent** | **float** | An estimate of the portion of the reporting period&#39;s activity for which the overall control system or approach (including both capture and control measures) were operating as designed (regardless of whether the control measure is due to rule or voluntary). | [optional] 
**control_first_inventory_year** | **float** | The inventory year for which the controls were implemented. | [optional] 
**control_last_inventory_year** | **float** | The last inventory year for which the controls were active. | [optional] 
**control_operating_months_number** | **float** | Number of months the control measure is being operated. | 
**control_measure_type** | **str** | The code that indicates the type of control measure. | 
**control_measure_type_desc** | **str** | The description of the code about the control measure. | [optional] 
**control_operating_status** | **str** | The operating status of the object of interest. Acceptable values are PLANNED, UNDER CONSTRUCTION, OPERATING, TEMPORARILY CLOSED, PERMANENTLY CLOSED, SEASONAL. | [optional] 
**control_operating_status_year** | **str** | The operating status year. | [optional] 
**control_source_system_program_code** | **str** | The code that represents the information management system which has responsibility for the data in a linked or interrelated information management system. | [optional] 
**control_equipment_type** | **str** | Name that identifies the piece of equipment or practice that is used to reduce one or more pollutants. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


