# RegistryGis

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**registry_id** | **str** | The identification number assigned by the EPA Facility Registry System to uniquely identify an object of interest. | [optional] 
**latitude** | **float** | The measure of the angular distance on a meridian north or south of the equator, as reported by the data source. | 
**longitude** | **float** | The measure of the angular distance on a meridian east or west of the prime meridian, as reported by the data source. | 
**accuracy_value** | **float** | The measure of the accuracy (in meters) of the latitude and longitude coordinates. | [optional] 
**collection_method_code** | **str** | The code that represents the method used to determine the latitude and longitude coordinates for a point on the earth. | [optional] 
**scale** | **float** | The number that represents the proportional distance on the ground for one unit of measure on the map or photo. Remarks: Mandatory for all horizontal data collection methods except for methods using Global Positioning System (GPS).. | [optional] 
**height_datum_code** | **str** | The code that represents the reference datum used in determining latitude and longitude coordinates. Allowable Values: Value Meaning 001 NAD27 002 NAD83 003 WGS84. | [optional] 
**ref_point_code** | **str** | The code that represents the place for which geographic coordinates were established. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


