# Pollutant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**control_id** | **str** | An identifier by which the control measure is referred to by the  information system that collected the air emission information. | [optional] 
**unit_id** | **str** | An identifier by which the unit is referred to by the  information system that collected the air emission information. | [optional] 
**process_id** | **str** | An identifier by which the processis referred to by the  information system that collected the air emission information. | [optional] 
**control_pollutant_name** | **str** | The name of the pollutant which is controlled by the control measure. | 
**control_reduction_efficiency_percent** | **float** | The reduction efficiency (in %) of the associated control measure for this pollutant. | [optional] 
**pollutant_code** | **str** | The code for the pollutant which is controlled by the control measure. | [optional] 
**site_path_id** | **str** | The identification number for the site path record. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


