# Process

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**process_id** | **str** | An identifier by which the Process is referred to by the primary EPA environmental information system that collects air emission information. | 
**process_alternate_id** | **str** | An alternative identification number maintained by an information management system for an environmental program. | 
**process_scc_code** | **str** | EPA Source Classification Code that identifies an emissions process. | [optional] 
**process_description** | **str** | A text description of the emissions process. | [optional] 
**process_operating_status** | **str** | The operating status of the object of interest. Acceptable values are PLANNED, UNDER CONSTRUCTION, OPERATING, TEMPORARILY CLOSED, PERMANENTLY CLOSED, SEASONAL. | [optional] 
**process_operating_status_year** | **str** | The operating status year. | [optional] 
**process_source_system_program_code** | **str** | The code that represents the information management system which has responsibility for the data in a linked or interrelated information management system. | [optional] 
**process_aircraft_engine_type_code** | **str** | Identifies the combination of aircraft and engine type for airport emissions. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


