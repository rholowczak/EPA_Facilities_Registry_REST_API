# AlternativeControlId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**program_control_id** | **str** | The program control identification number. | [optional] 
**alt_agency_control_id** | **str** | The alternative agency control identification number. | [optional] 
**effective_date** | **str** | The date the record became effective. | [optional] 
**end_date** | **str** | The end date for the record. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


