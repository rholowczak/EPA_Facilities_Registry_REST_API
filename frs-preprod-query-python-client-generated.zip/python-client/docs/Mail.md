# Mail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**affiliation_type** | **str** | The name that describes the capacity or function that an organization or individual serves for a facility site. Allowable Values (examples): Organization Individual Legally Responsible Entity  Report Certifier Legal Operator Regulatory Contact Waste Treater Public Contact Waste Handler  Technical Contact Land Owner Owner Parent Corporation Operator Owner/Operator. | [optional] 
**mailing_address** | **str** | The street address of the data. | [optional] 
**supplemental_address** | **str** | The supplemental address of the data. | [optional] 
**city_name** | **str** | The name of the city. | [optional] 
**state_code** | **str** | The state code for the address. | [optional] 
**state_name** | **str** | The state name for the mailing address. | [optional] 
**postal_code** | **str** | The postal code for the mailing address. | [optional] 
**country_name** | **str** | The country name for the mailing address. | [optional] 
**country_fips_code** | **str** | The FIPS code for the country. | [optional] 
**county_fips_code** | **str** | The FIPS code for the county. | [optional] 
**country_iso31661_alpha2** | **str** | The ISO 3166 1 Alpha 2 representation of the country. | [optional] 
**start_date** | **str** | The date this data started to be of interest in ISO 8601 format. | [optional] 
**end_date** | **str** | The date this data is no longer of interest in ISO 8601 format | [optional] 
**last_reported_date** | **str** | The most recent date the corresponding data was reported to the Source of Data in ISO 8601 format. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


