# swagger_client.FRSApi

All URIs are relative to *https://localhost/facilityiptquery/v1/FRS*

Method | HTTP request | Description
------------- | ------------- | -------------
[**query_alt_site_path_get**](FRSApi.md#query_alt_site_path_get) | **GET** /QueryAltSitePath | This service is used to search for Alt Site Path data in FRS.
[**query_alternative_control_id_get**](FRSApi.md#query_alternative_control_id_get) | **GET** /QueryAlternativeControlId | This service is used to search for Alternative Control Identification data in FRS.
[**query_alternative_id_get**](FRSApi.md#query_alternative_id_get) | **GET** /QueryAlternativeId | This service is used to search for Alternative ID data in FRS.
[**query_alternative_name_get**](FRSApi.md#query_alternative_name_get) | **GET** /QueryAlternativeName | This service is used to search for Alternative Name data in FRS.
[**query_association_get**](FRSApi.md#query_association_get) | **GET** /QueryAssociation | This service is used to search for Sub-facility Association data in FRS.
[**query_contact_get**](FRSApi.md#query_contact_get) | **GET** /QueryContact | This service is used to search for Contact data in FRS.
[**query_emissions_control_get**](FRSApi.md#query_emissions_control_get) | **GET** /QueryEmissionsControl | This service is used to search for Emissions Control data in FRS.
[**query_emissions_process_get**](FRSApi.md#query_emissions_process_get) | **GET** /QueryEmissionsProcess | This service is used to search for Emissions Process data in FRS.
[**query_emissions_unit_get**](FRSApi.md#query_emissions_unit_get) | **GET** /QueryEmissionsUnit | This service is used to search for Emissions Unit data in FRS.
[**query_interest_get**](FRSApi.md#query_interest_get) | **GET** /QueryInterest | This service is used to search for Interest data in FRS.
[**query_mail_get**](FRSApi.md#query_mail_get) | **GET** /QueryMail | This service is used to search for Mailing Address data in FRS.
[**query_naics_get**](FRSApi.md#query_naics_get) | **GET** /QueryNaics | This service is used to search for NAICs data in FRS.
[**query_organization_get**](FRSApi.md#query_organization_get) | **GET** /QueryOrganization | This service is used to search for Organization data in FRS.
[**query_path_assignment_get**](FRSApi.md#query_path_assignment_get) | **GET** /QueryPathAssignment | This service is used to search for Path Assignment data in FRS.
[**query_pollutant_get**](FRSApi.md#query_pollutant_get) | **GET** /QueryPollutant | This service is used to search for Pollutant data in FRS.
[**query_program_facility_get**](FRSApi.md#query_program_facility_get) | **GET** /QueryProgramFacility | This service is used to search for program facility data in FRS.
[**query_program_gis_get**](FRSApi.md#query_program_gis_get) | **GET** /QueryProgramGis | This service is used to search for Program Facility GIS data in FRS.
[**query_registry_get**](FRSApi.md#query_registry_get) | **GET** /QueryRegistry | This service is used to search for facility data in FRS.
[**query_registry_gis_get**](FRSApi.md#query_registry_gis_get) | **GET** /QueryRegistryGis | This service is used to search for facility GIS data in FRS.
[**query_release_point_apportionment_get**](FRSApi.md#query_release_point_apportionment_get) | **GET** /QueryReleasePointApportionment | This service is used to search for Release Point Apportionment data in FRS.
[**query_release_point_get**](FRSApi.md#query_release_point_get) | **GET** /QueryReleasePoint | This service is used to search for Release Point data in FRS.
[**query_sic_get**](FRSApi.md#query_sic_get) | **GET** /QuerySic | This service is used to search for SIC data in FRS.
[**query_site_path_get**](FRSApi.md#query_site_path_get) | **GET** /QuerySitePath | This service is used to search for Site Path data in FRS.
[**query_supplemental_interest_get**](FRSApi.md#query_supplemental_interest_get) | **GET** /QuerySupplementalInterest | This service is used to search for Supplemental Interest data in FRS.
[**query_tribe_get**](FRSApi.md#query_tribe_get) | **GET** /QueryTribe | This service is used to search for Tribe data in FRS.


# **query_alt_site_path_get**
> list[AltSitePath] query_alt_site_path_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Alt Site Path data in FRS.

Users can search for Alt Site Paths in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Alt Site Path data in FRS.
    api_response = api_instance.query_alt_site_path_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_alt_site_path_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[AltSitePath]**](AltSitePath.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_alternative_control_id_get**
> list[AlternativeControlId] query_alternative_control_id_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Alternative Control Identification data in FRS.

Users can search for Alternative Control Identification in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Alternative Control Identification data in FRS.
    api_response = api_instance.query_alternative_control_id_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_alternative_control_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[AlternativeControlId]**](AlternativeControlId.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_alternative_id_get**
> list[AlternativeId] query_alternative_id_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Alternative ID data in FRS.

Users can search for Alternative ID in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Alternative ID data in FRS.
    api_response = api_instance.query_alternative_id_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_alternative_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[AlternativeId]**](AlternativeId.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_alternative_name_get**
> list[AlternativeName] query_alternative_name_get(user_id, password, registry_id, page_size=page_size, off_set=off_set)

This service is used to search for Alternative Name data in FRS.

Users can search for Alternative Name in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
registry_id = 'registry_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Alternative Name data in FRS.
    api_response = api_instance.query_alternative_name_get(user_id, password, registry_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_alternative_name_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **registry_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[AlternativeName]**](AlternativeName.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_association_get**
> list[Association] query_association_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Sub-facility Association data in FRS.

Users can search for Sub-facility Association in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Sub-facility Association data in FRS.
    api_response = api_instance.query_association_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_association_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Association]**](Association.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_contact_get**
> list[Contact] query_contact_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Contact data in FRS.

Users can search for Contact in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str |  (optional)
program_system_id = 'program_system_id_example' # str |  (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Contact data in FRS.
    api_response = api_instance.query_contact_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_contact_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | [optional] 
 **program_system_id** | **str**|  | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Contact]**](Contact.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_emissions_control_get**
> list[Control] query_emissions_control_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Emissions Control data in FRS.

Users can search for Emissions Control in the FRS system, based on a variety of search criteria.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Emissions Control data in FRS.
    api_response = api_instance.query_emissions_control_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_emissions_control_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Control]**](Control.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_emissions_process_get**
> list[Process] query_emissions_process_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Emissions Process data in FRS.

Users can search for Emissions Process in the FRS system, based on a variety of search criteria.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Emissions Process data in FRS.
    api_response = api_instance.query_emissions_process_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_emissions_process_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Process]**](Process.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_emissions_unit_get**
> list[Unit] query_emissions_unit_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Emissions Unit data in FRS.

Users can search for Emissions Unit in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Emissions Unit data in FRS.
    api_response = api_instance.query_emissions_unit_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_emissions_unit_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Unit]**](Unit.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_interest_get**
> list[Interest] query_interest_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Interest data in FRS.

Users can search for Interest in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str |  (optional)
program_system_id = 'program_system_id_example' # str |  (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Interest data in FRS.
    api_response = api_instance.query_interest_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_interest_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | [optional] 
 **program_system_id** | **str**|  | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Interest]**](Interest.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_mail_get**
> list[Mail] query_mail_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Mailing Address data in FRS.

Users can search for Mailing Address in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str |  (optional)
program_system_id = 'program_system_id_example' # str |  (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Mailing Address data in FRS.
    api_response = api_instance.query_mail_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_mail_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | [optional] 
 **program_system_id** | **str**|  | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Mail]**](Mail.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_naics_get**
> list[Naics] query_naics_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for NAICs data in FRS.

Users can search for NAICs in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str |  (optional)
program_system_id = 'program_system_id_example' # str |  (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for NAICs data in FRS.
    api_response = api_instance.query_naics_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_naics_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | [optional] 
 **program_system_id** | **str**|  | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Naics]**](Naics.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_organization_get**
> list[Organization] query_organization_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Organization data in FRS.

Users can search for Organization in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str |  (optional)
program_system_id = 'program_system_id_example' # str |  (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Organization data in FRS.
    api_response = api_instance.query_organization_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_organization_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | [optional] 
 **program_system_id** | **str**|  | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Organization]**](Organization.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_path_assignment_get**
> list[PathAssignment] query_path_assignment_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Path Assignment data in FRS.

Users can search for Path Assignments in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Path Assignment data in FRS.
    api_response = api_instance.query_path_assignment_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_path_assignment_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[PathAssignment]**](PathAssignment.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_pollutant_get**
> list[Pollutant] query_pollutant_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Pollutant data in FRS.

Users can search for Pollutant data in the FRS system, based on a variety of search criteria.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Pollutant data in FRS.
    api_response = api_instance.query_pollutant_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_pollutant_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Pollutant]**](Pollutant.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_program_facility_get**
> list[ProgramFacility] query_program_facility_get(user_id, password, registry_id=registry_id, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for program facility data in FRS.

This service is used to search for program facility data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
registry_id = 'registry_id_example' # str | The identification number assigned by the EPA Facility Registry System to uniquely identify an object of interest. (optional)
program_system_acronym = 'program_system_acronym_example' # str |  (optional)
program_system_id = 'program_system_id_example' # str |  (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for program facility data in FRS.
    api_response = api_instance.query_program_facility_get(user_id, password, registry_id=registry_id, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_program_facility_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **registry_id** | **str**| The identification number assigned by the EPA Facility Registry System to uniquely identify an object of interest. | [optional] 
 **program_system_acronym** | **str**|  | [optional] 
 **program_system_id** | **str**|  | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[ProgramFacility]**](ProgramFacility.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_program_gis_get**
> list[ProgramGIS] query_program_gis_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Program Facility GIS data in FRS.

Users can search for Program Facility GIS in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str |  (optional)
program_system_id = 'program_system_id_example' # str |  (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Program Facility GIS data in FRS.
    api_response = api_instance.query_program_gis_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_program_gis_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | [optional] 
 **program_system_id** | **str**|  | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[ProgramGIS]**](ProgramGIS.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_registry_get**
> list[Registry] query_registry_get(user_id, password, registry_id=registry_id, primary_name=primary_name, location_address=location_address, city_name=city_name, county_name=county_name, fips_code=fips_code, state_code=state_code, state_name=state_name, country_name=country_name, postal_code=postal_code, page_size=page_size, off_set=off_set)

This service is used to search for facility data in FRS.

This service is used to search for facility data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
registry_id = 'registry_id_example' # str | The identification number assigned by the EPA Facility Registry System to uniquely identify an object of interest. (optional)
primary_name = 'primary_name_example' # str | The primary name. Max 150 characters. (optional)
location_address = 'location_address_example' # str | The location address. Max 100 characters. (optional)
city_name = 'city_name_example' # str | The city name. Max 60 characters. (optional)
county_name = 'county_name_example' # str | The county name. Max 35 characters. (optional)
fips_code = 'fips_code_example' # str | The numberic FIPS code. Max 5 characters. (optional)
state_code = 'state_code_example' # str | The state code/abbreviation. Max 5 characters. (optional)
state_name = 'state_name_example' # str | The state name. Max 35 characters. (optional)
country_name = 'country_name_example' # str | The country name. Max 44 characters. (optional)
postal_code = 'postal_code_example' # str | The numeric postal code, dashes allowed. Max 14 characters. (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for facility data in FRS.
    api_response = api_instance.query_registry_get(user_id, password, registry_id=registry_id, primary_name=primary_name, location_address=location_address, city_name=city_name, county_name=county_name, fips_code=fips_code, state_code=state_code, state_name=state_name, country_name=country_name, postal_code=postal_code, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_registry_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **registry_id** | **str**| The identification number assigned by the EPA Facility Registry System to uniquely identify an object of interest. | [optional] 
 **primary_name** | **str**| The primary name. Max 150 characters. | [optional] 
 **location_address** | **str**| The location address. Max 100 characters. | [optional] 
 **city_name** | **str**| The city name. Max 60 characters. | [optional] 
 **county_name** | **str**| The county name. Max 35 characters. | [optional] 
 **fips_code** | **str**| The numberic FIPS code. Max 5 characters. | [optional] 
 **state_code** | **str**| The state code/abbreviation. Max 5 characters. | [optional] 
 **state_name** | **str**| The state name. Max 35 characters. | [optional] 
 **country_name** | **str**| The country name. Max 44 characters. | [optional] 
 **postal_code** | **str**| The numeric postal code, dashes allowed. Max 14 characters. | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Registry]**](Registry.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_registry_gis_get**
> list[RegistryGis] query_registry_gis_get(user_id, password, registry_id=registry_id, page_size=page_size, off_set=off_set)

This service is used to search for facility GIS data in FRS.

This service is used to search for facility GIS data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
registry_id = 'registry_id_example' # str | The identification number assigned by the EPA Facility Registry System to uniquely identify an object of interest. (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for facility GIS data in FRS.
    api_response = api_instance.query_registry_gis_get(user_id, password, registry_id=registry_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_registry_gis_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **registry_id** | **str**| The identification number assigned by the EPA Facility Registry System to uniquely identify an object of interest. | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[RegistryGis]**](RegistryGis.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_release_point_apportionment_get**
> list[ReleasePointApportionment] query_release_point_apportionment_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Release Point Apportionment data in FRS.

Users can search for Release Point Apportionments in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Release Point Apportionment data in FRS.
    api_response = api_instance.query_release_point_apportionment_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_release_point_apportionment_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[ReleasePointApportionment]**](ReleasePointApportionment.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_release_point_get**
> list[ReleasePoint] query_release_point_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Release Point data in FRS.

Users can search for Release Point in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Release Point data in FRS.
    api_response = api_instance.query_release_point_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_release_point_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[ReleasePoint]**](ReleasePoint.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_sic_get**
> list[Sic] query_sic_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for SIC data in FRS.

Users can search for SIC in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str |  (optional)
program_system_id = 'program_system_id_example' # str |  (optional)
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for SIC data in FRS.
    api_response = api_instance.query_sic_get(user_id, password, program_system_acronym=program_system_acronym, program_system_id=program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_sic_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | [optional] 
 **program_system_id** | **str**|  | [optional] 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Sic]**](Sic.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_site_path_get**
> list[SitePath] query_site_path_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Site Path data in FRS.

Users can search for Site Paths in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Site Path data in FRS.
    api_response = api_instance.query_site_path_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_site_path_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[SitePath]**](SitePath.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_supplemental_interest_get**
> list[SupplementalInterest] query_supplemental_interest_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Supplemental Interest data in FRS.

Users can search for Supplemental Interest in the FRS system, based on a variety of search criteria.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Supplemental Interest data in FRS.
    api_response = api_instance.query_supplemental_interest_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_supplemental_interest_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[SupplementalInterest]**](SupplementalInterest.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **query_tribe_get**
> list[Tribe] query_tribe_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)

This service is used to search for Tribe data in FRS.

Users can search for Tribe in the FRS system, based on a variety of search criteria

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
program_system_acronym = 'program_system_acronym_example' # str | 
program_system_id = 'program_system_id_example' # str | 
page_size = 'page_size_example' # str |  (optional)
off_set = 'off_set_example' # str |  (optional)

try:
    # This service is used to search for Tribe data in FRS.
    api_response = api_instance.query_tribe_get(user_id, password, program_system_acronym, program_system_id, page_size=page_size, off_set=off_set)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->query_tribe_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **program_system_acronym** | **str**|  | 
 **program_system_id** | **str**|  | 
 **page_size** | **str**|  | [optional] 
 **off_set** | **str**|  | [optional] 

### Return type

[**list[Tribe]**](Tribe.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

