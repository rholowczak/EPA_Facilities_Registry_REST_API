# SitePath

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**site_path_id** | **str** | The identification number for this record. | [optional] 
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**eis_path_id** | **str** | The identification number for the associated Environmental Information System record. | [optional] 
**path_name** | **str** | The site path. | [optional] 
**path_description** | **str** | A description of the site path. | [optional] 
**create_date** | **str** | The date the record was created. | [optional] 
**refresh_date** | **str** | The date the record was refreshed. | [optional] 
**user_id** | **str** | The user ID of the person who entered the data or the method by which the data was entered into the system. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


