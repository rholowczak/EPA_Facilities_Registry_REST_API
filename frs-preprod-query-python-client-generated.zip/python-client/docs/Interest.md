# Interest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**interest_type** | **str** | The type of interest. | [optional] 
**federal_state_code** | **str** | Indicator if the interest is a federal, state, or tribal code.  Acceptable values are F (Federal), S (State), and T (Tribal). | [optional] 
**start_date** | **str** | The date this data started to be of interest in ISO 8601 format. | [optional] 
**start_date_qualifier** | **str** | A qualifier for what the startDate value means. | [optional] 
**end_date** | **str** | The date this data is no longer of interest in ISO 8601 format | [optional] 
**end_date_qualifier** | **str** | A qualifier for what the endDate value means. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


