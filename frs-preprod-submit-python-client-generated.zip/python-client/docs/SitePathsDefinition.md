# SitePathsDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**site_path_id** | **str** | Primary key of the SITE_PATHS table. | [optional] 
**facility_site_id** | **str** | The Facility Site Identifier to which the control equipment resides. | [optional] 
**eis_path_id** | **float** | Unique EIS Identifier for the site path. | [optional] 
**path_name** | **str** | Short Name for the path. Must be unique within the site. | 
**path_description** | **str** | Description for the site path. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


