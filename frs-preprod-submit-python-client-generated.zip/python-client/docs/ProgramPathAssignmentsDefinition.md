# ProgramPathAssignmentsDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path_assignment_id** | **str** | Primary key of the PATH_ASSIGNMENTS table. | [optional] 
**site_path_id** | **str** | Primary key of the SITE_PATHS table. | 
**assigned_control_id** | **float** | Primary key of the SITE_CONTROLS table. Identifies that the Control Belongs to the Path | [optional] 
**assigned_path_id** | **str** | Primary key of the SITE_PATHS table. Identifies that the path belongs to the larger Path | 
**sequence_number** | **str** | The order in which the item on the path is encountered. | [optional] 
**avg_percent_apprt** | **str** | The percentage of the air that is diverted to the given control or path. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


