# swagger_client.FRSApi

All URIs are relative to *https://localhost/facilityiptsubmit/v1/FRS*

Method | HTTP request | Description
------------- | ------------- | -------------
[**bulk_upload_status_get**](FRSApi.md#bulk_upload_status_get) | **GET** /BulkUpload/Status | This service is used to view the status of the bulk upload file and return possible feedback.
[**bulk_upload_upload_post**](FRSApi.md#bulk_upload_upload_post) | **POST** /BulkUpload/Upload | This service is used to upload large data sets to FRS all at once that includes all of the schemas.  An asynchronous process will be executed to process the data.
[**submit_alternative_id_post**](FRSApi.md#submit_alternative_id_post) | **POST** /SubmitAlternativeId | This service is used to add, update, and delete Alternative ID data in FRS.
[**submit_alternative_name_post**](FRSApi.md#submit_alternative_name_post) | **POST** /SubmitAlternativeName | This service is used to add, update, and delete Alternative ID data in FRS.
[**submit_contact_post**](FRSApi.md#submit_contact_post) | **POST** /SubmitContact | This service is used to add, update, and delete Contact data in FRS.
[**submit_facility_post**](FRSApi.md#submit_facility_post) | **POST** /SubmitFacility | This service is used to add, update, and delete facility data in FRS.
[**submit_geospatial_post**](FRSApi.md#submit_geospatial_post) | **POST** /SubmitGeospatial | This service is used to add and update Geospatial data in FRS. There is no operation parameter for this service. FRS expects the entire record each time and will delete any part of the geospatial record not included. This data is not integrated in real-time how the other services are processed.  This data is processed into FRS each week on Friday night.
[**submit_interest_post**](FRSApi.md#submit_interest_post) | **POST** /SubmitInterest | This service is used to add, update, and delete environmental interest data in FRS.
[**submit_mailing_address_post**](FRSApi.md#submit_mailing_address_post) | **POST** /SubmitMailingAddress | This service is used to add, update, and delete Mailing Address data in FRS.
[**submit_naics_post**](FRSApi.md#submit_naics_post) | **POST** /SubmitNaics | This service is used to add, update, and delete NAICS data in FRS.
[**submit_organization_post**](FRSApi.md#submit_organization_post) | **POST** /SubmitOrganization | This service is used to add, update, and delete Organization data in FRS.
[**submit_sic_post**](FRSApi.md#submit_sic_post) | **POST** /SubmitSic | This service is used to add, update, and delete SIC data in FRS.
[**submit_sub_facility_post**](FRSApi.md#submit_sub_facility_post) | **POST** /SubmitSubFacility | This service is used to add, update, and delete Sub-Facility data in FRS. There is no operation parameter for this service. FRS expects the entire record each time and will delete any part of the sub-facility record not included.
[**submit_supplemental_interest_post**](FRSApi.md#submit_supplemental_interest_post) | **POST** /SubmitSupplementalInterest | This service is used to add, update, and delete Supplemental Interest data in FRS. 
[**submit_tribe_post**](FRSApi.md#submit_tribe_post) | **POST** /SubmitTribe | This service is used to add, update, and delete Tribe data in FRS.


# **bulk_upload_status_get**
> object bulk_upload_status_get(user_id, password, transaction_id)

This service is used to view the status of the bulk upload file and return possible feedback.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
transaction_id = 'transaction_id_example' # str | 

try:
    # This service is used to view the status of the bulk upload file and return possible feedback.
    api_response = api_instance.bulk_upload_status_get(user_id, password, transaction_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->bulk_upload_status_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **transaction_id** | **str**|  | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **bulk_upload_upload_post**
> object bulk_upload_upload_post(user_id, password, file)

This service is used to upload large data sets to FRS all at once that includes all of the schemas.  An asynchronous process will be executed to process the data.

See sample file here for more details <a href=\"../resources/bulk_upload_example_subfacility.zip\">download</a>.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | User ID
password = 'password_example' # str | 
file = '/path/to/file.txt' # file | The uploaded file data in ZIP format.

try:
    # This service is used to upload large data sets to FRS all at once that includes all of the schemas.  An asynchronous process will be executed to process the data.
    api_response = api_instance.bulk_upload_upload_post(user_id, password, file)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->bulk_upload_upload_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| User ID | 
 **password** | **str**|  | 
 **file** | **file**| The uploaded file data in ZIP format. | 

### Return type

**object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_alternative_id_post**
> str submit_alternative_id_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete Alternative ID data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.AlternativeId() # AlternativeId | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update. (optional)

try:
    # This service is used to add, update, and delete Alternative ID data in FRS.
    api_response = api_instance.submit_alternative_id_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_alternative_id_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**AlternativeId**](AlternativeId.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_alternative_name_post**
> str submit_alternative_name_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete Alternative ID data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.AlternativeName() # AlternativeName | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update. (optional)

try:
    # This service is used to add, update, and delete Alternative ID data in FRS.
    api_response = api_instance.submit_alternative_name_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_alternative_name_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**AlternativeName**](AlternativeName.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_contact_post**
> str submit_contact_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete Contact data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.Contact() # Contact | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update. (optional)

try:
    # This service is used to add, update, and delete Contact data in FRS.
    api_response = api_instance.submit_contact_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_contact_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**Contact**](Contact.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_facility_post**
> str submit_facility_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete facility data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.ProgramFacility() # ProgramFacility | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update.  If a program facility record is deleted then all other associated program data will be deleted from FRS too. (optional)

try:
    # This service is used to add, update, and delete facility data in FRS.
    api_response = api_instance.submit_facility_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_facility_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**ProgramFacility**](ProgramFacility.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update.  If a program facility record is deleted then all other associated program data will be deleted from FRS too. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_geospatial_post**
> str submit_geospatial_post(user_id, password, submit_text)

This service is used to add and update Geospatial data in FRS. There is no operation parameter for this service. FRS expects the entire record each time and will delete any part of the geospatial record not included. This data is not integrated in real-time how the other services are processed.  This data is processed into FRS each week on Friday night.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.GIS() # GIS | 

try:
    # This service is used to add and update Geospatial data in FRS. There is no operation parameter for this service. FRS expects the entire record each time and will delete any part of the geospatial record not included. This data is not integrated in real-time how the other services are processed.  This data is processed into FRS each week on Friday night.
    api_response = api_instance.submit_geospatial_post(user_id, password, submit_text)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_geospatial_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**GIS**](GIS.md)|  | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_interest_post**
> str submit_interest_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete environmental interest data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.Interest() # Interest | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update. (optional)

try:
    # This service is used to add, update, and delete environmental interest data in FRS.
    api_response = api_instance.submit_interest_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_interest_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**Interest**](Interest.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_mailing_address_post**
> str submit_mailing_address_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete Mailing Address data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.Mail() # Mail | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update. (optional)

try:
    # This service is used to add, update, and delete Mailing Address data in FRS.
    api_response = api_instance.submit_mailing_address_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_mailing_address_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**Mail**](Mail.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_naics_post**
> str submit_naics_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete NAICS data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.Naics() # Naics | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update. (optional)

try:
    # This service is used to add, update, and delete NAICS data in FRS.
    api_response = api_instance.submit_naics_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_naics_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**Naics**](Naics.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_organization_post**
> str submit_organization_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete Organization data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.Organization() # Organization | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update. (optional)

try:
    # This service is used to add, update, and delete Organization data in FRS.
    api_response = api_instance.submit_organization_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_organization_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**Organization**](Organization.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_sic_post**
> str submit_sic_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete SIC data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.Sic() # Sic | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update. (optional)

try:
    # This service is used to add, update, and delete SIC data in FRS.
    api_response = api_instance.submit_sic_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_sic_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**Sic**](Sic.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_sub_facility_post**
> str submit_sub_facility_post(user_id, password, submit_text)

This service is used to add, update, and delete Sub-Facility data in FRS. There is no operation parameter for this service. FRS expects the entire record each time and will delete any part of the sub-facility record not included.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.SubFacility() # SubFacility | 

try:
    # This service is used to add, update, and delete Sub-Facility data in FRS. There is no operation parameter for this service. FRS expects the entire record each time and will delete any part of the sub-facility record not included.
    api_response = api_instance.submit_sub_facility_post(user_id, password, submit_text)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_sub_facility_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**SubFacility**](SubFacility.md)|  | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_supplemental_interest_post**
> str submit_supplemental_interest_post(user_id, password, submit_text)

This service is used to add, update, and delete Supplemental Interest data in FRS. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.SupplementalInterest() # SupplementalInterest | 

try:
    # This service is used to add, update, and delete Supplemental Interest data in FRS. 
    api_response = api_instance.submit_supplemental_interest_post(user_id, password, submit_text)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_supplemental_interest_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**SupplementalInterest**](SupplementalInterest.md)|  | 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **submit_tribe_post**
> str submit_tribe_post(user_id, password, submit_text, operation=operation)

This service is used to add, update, and delete Tribe data in FRS.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FRSApi()
user_id = 'user_id_example' # str | NAAS User ID
password = 'password_example' # str | NAAS user password
submit_text = swagger_client.Tribe() # Tribe | 
operation = 'operation_example' # str | The operation to perform on the record.  Specify 'Delete' to delete the record, otherwise it will be treated as an insert or update. (optional)

try:
    # This service is used to add, update, and delete Tribe data in FRS.
    api_response = api_instance.submit_tribe_post(user_id, password, submit_text, operation=operation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FRSApi->submit_tribe_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**| NAAS User ID | 
 **password** | **str**| NAAS user password | 
 **submit_text** | [**Tribe**](Tribe.md)|  | 
 **operation** | **str**| The operation to perform on the record.  Specify &#39;Delete&#39; to delete the record, otherwise it will be treated as an insert or update. | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

