# SubFacility

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alt_site_paths** | [**list[AltSitePathsDefinition]**](AltSitePathsDefinition.md) |  | [optional] 
**emissions_unit** | [**list[UnitDefinition]**](UnitDefinition.md) |  | [optional] 
**emissions_process** | [**list[ProcessDefinition]**](ProcessDefinition.md) |  | [optional] 
**emissions_control** | [**list[ControlDefinition]**](ControlDefinition.md) |  | [optional] 
**program_path_assignments** | [**list[ProgramPathAssignmentsDefinition]**](ProgramPathAssignmentsDefinition.md) |  | [optional] 
**release_point** | [**list[ReleasePointDefinition]**](ReleasePointDefinition.md) |  | [optional] 
**release_point_apprt** | [**list[ReleasePointApprtDefinition]**](ReleasePointApprtDefinition.md) |  | [optional] 
**site_paths** | [**list[SitePathsDefinition]**](SitePathsDefinition.md) |  | [optional] 
**sub_facility_associations** | [**list[AssociationDefinition]**](AssociationDefinition.md) |  | [optional] 
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


