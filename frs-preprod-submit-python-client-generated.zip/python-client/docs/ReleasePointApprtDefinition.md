# ReleasePointApprtDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rel_point_apprt_id** | **str** | A unique sequence identifier assigned by the EIS. This data in this column is not made public. | 
**process_id** | **str** | A unique sequence identifier assigned by the EIS. This data in this column is not made public. | 
**release_point_id** | **float** | A unique sequence identifier assigned by the EIS. This data in this column is not made public. | 
**average_percent_emissions** | **str** | The percent of emissions from an emissions process or emissions unit that are vented through a release point. | 
**eis_comment** | **str** | Any comments regardig the reported data. | [optional] 
**site_path_id** | **str** | Reference to what control path affects the release point apportionment. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


