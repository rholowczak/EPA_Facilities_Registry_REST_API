# Tribe

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**epa_id** | **float** | The EPA internal identifier of the tribe. | [optional] 
**bia_code** | **str** | The code that represents the American Indian tribe, band, or Alaskan Native entity. Permissible values for the Tribal Code data element are based on the BIA official list of tribal codes, e.g., 007 (St. Regis Band of Mohawk Indians of New York) or F09 (Birch Creek Tribe). | [optional] 
**tribe_name** | **str** | The name of the American Indian tribe, band, or Alaskan Native entity. Permissible values for the Tribal Name data element are based on the BIA federally recognized tribal list, e.g., St. Regis Band of Mohawk Indians of New York. | [optional] 
**start_date** | **str** | The date this data started to be of interest in ISO 8601 format. | [optional] 
**end_date** | **str** | The date this data is no longer of interest in ISO 8601 format | [optional] 
**last_reported_date** | **str** | The most recent date the corresponding data was reported to the Source of Data in ISO 8601 format. | [optional] 
**sensitive_index** | **str** | Indicates whether or not the associated data is enforcement sensitive. | [optional] 
**public_index** | **str** | Indicates whether or not the associated data is accessible by the public on the Internet. | [optional] 
**user_id** | **str** | The user ID of the person who entered the data or the method by which the data was entered into the system. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


