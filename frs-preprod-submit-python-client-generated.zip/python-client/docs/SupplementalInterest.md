# SupplementalInterest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**supplemental_program_system_acronym** | **str** |  | 
**supplemental_program_system_id** | **str** |  | 
**supplemental_interest_type** | **str** |  | [optional] 
**user_id** | **str** | The user ID of the person who entered the data or the method by which the data was entered into the system. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


