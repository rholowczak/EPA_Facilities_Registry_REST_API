# AltSitePathsDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alt_site_path_id** | **str** | Primary key of the ALT_SITE_PATHS table. | [optional] 
**site_path_id** | **str** | Foreign key to the SITE_PATHS table. | 
**program_system_id** | **float** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**alt_agency_path_id** | **str** | The alternative agency path identification number. | 
**effective_date** | **str** | The date this data is effective in ISO 8601 format. | [optional] 
**end_date** | **str** | The date this data is no longer of interest in ISO 8601 format | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


