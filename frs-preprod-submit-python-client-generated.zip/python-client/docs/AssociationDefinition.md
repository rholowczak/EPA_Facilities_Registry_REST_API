# AssociationDefinition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sub_association_internal_id1** | **str** | the sub-component ID (or internal ID if newly created) to be associated with internalID2 | 
**sub_association_internal_id2** | **str** | the sub-component ID (or internal ID if newly created) to be associated with internalID1 | 
**sub_association_average_percent** | **float** | The average percent of subAssociationInternalId1/subAssociationProgramSystemId1 as it relates to subAssociationInternalId2/subAssociationProgramSystemId2. For example, the average percent of emissions vented through a release point.  | 
**control_order** | **str** | stores the order a control variable is in the chain of the specified relationship | [optional] 
**series_parallel_ind** | **str** | denotes if a component is in a parallel sequence (or order) with another component | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


