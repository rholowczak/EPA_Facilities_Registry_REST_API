# GIS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**latitude** | **float** | The measure of the angular distance on a meridian north or south of the equator, as reported by the data source. | 
**longitude** | **float** | The measure of the angular distance on a meridian east or west of the prime meridian, as reported by the data source. | 
**accuracy_value** | **float** | The measure of the accuracy (in meters) of the latitude and longitude coordinates. | [optional] 
**vertical_measure** | **float** | The measure of elevation (i.e., the altitude), in meters, above or below a reference datum. | [optional] 
**vertical_method_code** | **str** | The code that represents the method used to collect the vertical measure (i.e., the altitude) of a reference point. | [optional] 
**vertical_datum_code** | **str** | The code that represents the reference datum used to determine the vertical measure (i.e., the altitude). Allowable Values: Value Meaning 001 NAVD88 002 NGVD29 003 MEAN SEA-LEVEL 004 LOCAL TIDAL DATUM. | [optional] 
**vertical_accuracy** | **float** | The measure of the accuracy (in meters) of the vertical measure (i.e., the altitude) of a reference point. | [optional] 
**collection_method_code** | **str** | The code that represents the method used to determine the latitude and longitude coordinates for a point on the earth. | [optional] 
**scale** | **float** | The number that represents the proportional distance on the ground for one unit of measure on the map or photo. Remarks: Mandatory for all horizontal data collection methods except for methods using Global Positioning System (GPS).. | [optional] 
**height_datum_code** | **str** | The code that represents the reference datum used in determining latitude and longitude coordinates. Allowable Values: Value Meaning 001 NAD27 002 NAD83 003 WGS84. | [optional] 
**collection_date** | **str** | The calendar data when data were collected. | [optional] 
**comment_text** | **str** | The text that provides additional information about the geographic coordinates. | [optional] 
**geometric_type_code** | **str** | The code that represents the geometric entity represented by one point or a sequence of latitude and longitude points. Allowable Values: Value Meaning 001 POINT 002 LINE 003 AREA 004 REGION 005 ROUTE. | [optional] 
**ref_point_code** | **str** | The code that represents the place for which geographic coordinates were established. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


