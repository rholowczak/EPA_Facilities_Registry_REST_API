# PollutantObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**control_pollutant_name** | **str** | The name of the pollutant which is controlled by the control measure. | 
**control_reduction_efficiency_percent** | **float** | The reduction efficiency (in %) of the associated control measure for this pollutant | [optional] 
**pollutant_code** | **str** | The code for the pollutant which is controlled by the control measure. | [optional] 
**site_path_id** | **str** | Foreign key to the SITE_PATHS table. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


