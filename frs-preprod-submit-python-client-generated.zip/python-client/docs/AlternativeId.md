# AlternativeId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**alternative_id** | **str** | An alternative identification number maintained by an information management system for an environmental program. | 
**alternative_id_type** | **str** | The type of alternative identification number (for example, STATE PERMIT NUMBER), or the abbreviated name of the environmental information system that references the alternative identification number (for example, TRIS, PCS). | 
**last_reported_date** | **str** | The most recent date the corresponding individual data was reported to the Source of Data. | [optional] 
**sensitive_index** | **str** | Indicates whether or not the associated data is enforcement sensitive. | [optional] 
**public_index** | **str** | Indicates whether or not the associated data is accessible by the public on the Internet. | [optional] 
**user_id** | **str** | The user ID of the person who entered the data or the method by which the data was entered into the system. | [optional] 
**start_date** | **str** | The date this data started to be of interest in ISO 8601 format. | [optional] 
**end_date** | **str** | The date this data is no longer of interest in ISO 8601 format | [optional] 
**responsible_agency** | **str** | The agency or bureau name (e.g., state DEQ) associated with the facility. | [optional] 
**pgm_sub_sys_id** | **str** | An identifier by which a sub-facility component is referred to by the primary EPA environmental information system that collects air emission information. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


