# ProgramFacility

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**registry_id** | **str** | The identification number assigned by the EPA Facility Registry System to uniquely identify an object of interest. | [optional] 
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**primary_name** | **str** | The public or commercial name of a facility site (i.e., the full name that commonly appears on invoices, signs, or other business documents, or as assigned by the state when the name is ambiguous). | 
**location_address** | **str** | The address that describes the physical (geographic) location of the front door or main entrance of a facility site, including urban-style street address or rural address. | 
**supplemental_location** | **str** | The text that provides additional information about a place, including a building name with its secondary unit and number, an industrial park name, an installation name, or descriptive text where no formal address is available. | [optional] 
**city_name** | **str** | The name of the city, town, village or other locality, when identifiable, within whose boundaries (the majority of) the facility site is located.  This is not always the same as the city used for USPS mail delivery. | 
**county_name** | **str** |  The name of the U.S. county or county equivalent in which the facility site is physically located. | 
**county_fips_code** | **str** | The code that represents the county or county equivalent and the state or state equivalent of the United States. | [optional] 
**state_code** | **str** | The U.S. Postal Service abbreviation that represents the state or state equivalent for the U.S. and Canada. | 
**state_name** | **str** | The name of a principal administrative subdivision of the United States, Canada, or Mexico. | [optional] 
**country_name** | **str** | The name that represents a primary geopolitical unit of the world. | 
**postal_code** | **str** | The combination of the 5-digit Zone Improvement Plan (ZIP) code and the four-digit extension code (if available) that represents the geographic segment that is a subunit of the ZIP Code, assigned by the U.S. Postal Service to a geographic location; or the postal zone specific to the country, other than the U.S., where the facility site is located. | 
**is_federal_facility_flag** | **str** | Code indicating whether or not the facility site is the property of the federal government. | [optional] 
**agency_id** | **str** | The Federal Agency/Bureau code.  The five character code consists of a letter followed by four numbers.  There are four possible letters that can occupy the first character position:  C for Civilian Federal Agency; D for Department of Defense; E for Department of Energy; X for Unknown.  The second and third characters represent the agency code, while the fourth and fifth characters represent the bureau code. | [optional] 
**site_type_name** | **str** | The descriptive name for the type of facility. Allowable Values (example):POTENTIALLY CONTAMINATED SITE, NETWORK, MONITORING STATION, STATIONARY, WATER SYSTEM, MOBILE, FACILITY, PIPELINE, CONTAMINATION ADDRESSED, CONTAMINATED SITE, BROWNFIELDS SITE, PORTABLE, OFF-SHORE PLATFORM. | 
**is_small_business_flag** | **str** | Y/N code indicating whether or not a business is requesting relief under EPA Small Business Policy, which applies to businesses having less than 100 employees. | [optional] 
**merged_registry_ids** | **str** | A pipe delimted list of FRS Registry Records to be be merged into the registryId value. | [optional] 
**huc_code8** | **str** | The HUC 8 Code for the registry item. | [optional] 
**huc_code12** | **str** | The HUC 12 Code for the registry item. | [optional] 
**is_potw_flag** | **str** | Indicates whether this registry item is of POTW. | [optional] 
**country_iso31661_alpha2** | **str** | The country code is ISO 3166 1 Alpha 2 format. | [optional] 
**env_justice_code** | **str** | The code that identifies the type of environmental justice concern affecting the facility or enforcement action. | [optional] 
**facility_management_type_code** | **str** | The type of facility management performed for the registry item. | [optional] 
**facility_owner_type** | **str** | The type of facility owner for the registry id. Allowable Values (xample): BANK/LOAN COMPANY, BROWNFIELDS/PUBLIC, COUNTY OWNED, DISTRICT OWNED, FEDERALLY OWNED, NEITHER, FORMERLY FEDERALLY OWNED OR OPERATED, GOVERNMENT OWNED / CONTRACTOR OPERATED, MIXED OWNERSHIP, MUNICIPALITY, PRIVATE, PRIVATELY OWNED / GOVERNMENT OPERATED, PROPERTY DEFAULTED BACK TO GOVERNMENT, STATE OWNED, TRIBAL GOVERNMENT, TRUSTEE, FEDERAL, TRUSTEE, STATE, FEDERAL, OTHER, UNKNOWN, GOCO  | [optional] 
**legislative_district_number** | **str** | The legislative district number for the registry item. | [optional] 
**location_description** | **str** | A location description for the registry item. | [optional] 
**operating_status** | **str** | The operating status of the registry item. | [optional] 
**operating_status_date** | **str** | The last date the operating status was collected. | [optional] 
**operating_status_year** | **float** | The last year the operating status was collected. | [optional] 
**population_served** | **float** | The amount of population served by the registry item. | [optional] 
**is_portable_source_flag** | **str** | Indicates if this is a portable registry item. | [optional] 
**is_sensitive_flag** | **str** | Indicates whether or not the associated data is enforcement sensitive. | [optional] 
**is_public_flag** | **str** | Indicates whether or not the associated data is accessible by the public on the Internet. | [optional] 
**start_date** | **str** | The date this data started to be of interest in ISO 8601 format. | [optional] 
**end_date** | **str** | The date this data is no longer of interest in ISO 8601 format | [optional] 
**last_reported_date** | **str** | The most recent date the corresponding data was reported to the Source of Data in ISO 8601 format. | [optional] 
**user_id** | **str** | The user ID of the person who entered the data or the method by which the data was entered into the system. | 
**facility_source_system_program_code** | **str** | The code that represents the information management system which has responsibility for the data in a linked or interrelated information management system. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


