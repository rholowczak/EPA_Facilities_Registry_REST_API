# Naics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**program_system_acronym** | **str** | The abbreviated name that represents the name of an information management system for an environmental program. | 
**program_system_id** | **str** | The identification number, such as the permit number, assigned by an information management system that represents a facility site, waste site, operable unit, or other feature tracked by that Environmental Information System. | 
**program_sub_system_id** | **str** | The identification number assigned by an information management system that represents a component or feature of a facility site. | [optional] 
**naics_code** | **str** | The code that represents a subdivision of an industry that accommodates user needs in the United States (six-digits). | 
**primary_indicator** | **str** | Indicates whether this NAICS is the primary for the registry item. Acceptable values are: PRIMARY, SECONDARY, UNKNOWN. | 
**start_date** | **str** | The date this data started to be of interest in ISO 8601 format. | [optional] 
**end_date** | **str** | The date this data is no longer of interest in ISO 8601 format | [optional] 
**last_reported_date** | **str** | The most recent date the corresponding data was reported to the Source of Data in ISO 8601 format. | [optional] 
**sensitive_index** | **str** | Indicates whether or not the associated data is enforcement sensitive. | [optional] 
**public_index** | **str** | Indicates whether or not the associated data is accessible by the public on the Internet. | [optional] 
**user_id** | **str** | The user ID of the person who entered the data or the method by which the data was entered into the system. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


